<?php
$string['pluginname'] = 'Solomon Test';
$string['modulename'] = 'Solomon Test';
$string['modulenameplural'] = 'Solomon Tests';
$string['name'] = 'Test name';
