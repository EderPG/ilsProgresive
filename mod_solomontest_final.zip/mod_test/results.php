<?php
require_once('../../config.php');
require_login();

$id = required_param('id', PARAM_INT);
$cm = get_coursemodule_from_id('solomontest', $id, 0, false, MUST_EXIST);
$context = context_module::instance($cm->id);
require_capability('moodle/course:manageactivities', $context);

$solomontest = $DB->get_record('solomontest', ['id' => $cm->instance], '*', MUST_EXIST);
$PAGE->set_url('/mod/solomontest/results.php', ['id' => $id]);
$PAGE->set_title('Resultados del Test de Solomon');
$PAGE->set_heading('Resultados del Test de Solomon');

echo $OUTPUT->header();
echo $OUTPUT->heading('Distribución de estilos de aprendizaje');

$records = $DB->get_records('solomontest_results', ['solomontestid' => $solomontest->id]);

$total_visual = 0;
$total_auditivo = 0;
$total_kinestesico = 0;

foreach ($records as $r) {
    $total_visual += $r->visual;
    $total_auditivo += $r->auditivo;
    $total_kinestesico += $r->kinestesico;
}
?>

<canvas id="chart" width="400" height="200"></canvas>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById("chart").getContext("2d");
const chart = new Chart(ctx, {
    type: "bar",
    data: {
        labels: ["Visual", "Auditivo", "Kinestésico"],
        datasets: [{
            label: "Respuestas acumuladas",
            data: [<?php echo $total_visual; ?>, <?php echo $total_auditivo; ?>, <?php echo $total_kinestesico; ?>],
            backgroundColor: ["#4e79a7", "#f28e2b", "#59a14f"]
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false },
            title: { display: true, text: "Estilos de Aprendizaje (Grupo)" }
        },
        scales: {
            y: { beginAtZero: true }
        }
    }
});
</script>

<?php
echo $OUTPUT->footer();
?>
