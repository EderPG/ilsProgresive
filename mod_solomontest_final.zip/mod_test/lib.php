<?php
defined('MOODLE_INTERNAL') || die();

function solomontest_add_instance($data, $mform) {
    global $DB;
    $data->timecreated = time();
    return $DB->insert_record('solomontest', $data);
}

function solomontest_update_instance($data, $mform) {
    global $DB;
    $data->id = $data->instance;
    $data->timemodified = time();
    return $DB->update_record('solomontest', $data);
}

function solomontest_delete_instance($id) {
    global $DB;
    return $DB->delete_records('solomontest', ['id' => $id]);
}
