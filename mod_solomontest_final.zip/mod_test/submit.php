<?php
require_once('../../config.php');
require_login();

$id = required_param('id', PARAM_INT);
$cm = get_coursemodule_from_id('solomontest', $id, 0, false, MUST_EXIST);
$solomontest = $DB->get_record('solomontest', ['id' => $cm->instance], '*', MUST_EXIST);
$course = $DB->get_record('course', ['id' => $cm->course], '*', MUST_EXIST);

$userid = $USER->id;

// Verificar si ya respondió (opcional: evitar duplicados)
$exists = $DB->record_exists('solomontest_results', ['solomontestid' => $solomontest->id, 'userid' => $userid]);
if (!$exists) {
    $counts = ['visual' => 0, 'auditivo' => 0, 'kinestesico' => 0];
    for ($i = 0; $i < 20; $i++) {
        $q = required_param('q' . $i, PARAM_TEXT);
        if (array_key_exists($q, $counts)) {
            $counts[$q]++;
        }
    }

    $record = new stdClass();
    $record->solomontestid = $solomontest->id;
    $record->userid = $userid;
    $record->visual = $counts['visual'];
    $record->auditivo = $counts['auditivo'];
    $record->kinestesico = $counts['kinestesico'];
    $record->timecreated = time();
    $DB->insert_record('solomontest_results', $record);
}

// Redirigir al curso
redirect(new moodle_url('/course/view.php', ['id' => $course->id]));
?>
