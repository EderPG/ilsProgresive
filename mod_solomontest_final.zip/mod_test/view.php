<?php
require_once('../../config.php');
require_login();

$id = required_param('id', PARAM_INT);
$cm = get_coursemodule_from_id('solomontest', $id, 0, false, MUST_EXIST);
$course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
$solomontest = $DB->get_record('solomontest', array('id' => $cm->instance), '*', MUST_EXIST);

$PAGE->set_url('/mod/solomontest/view.php', array('id' => $id));
$PAGE->set_title($solomontest->name);
$PAGE->set_heading($course->fullname);

echo $OUTPUT->header();
echo $OUTPUT->heading(format_string($solomontest->name));

echo '<form method="post" action="submit.php?id=' . $id . '">';
$questions = ['Prefiero aprender a través de imágenes, gráficos y esquemas.', 'Me concentro mejor cuando escucho explicaciones.', 'Aprendo mejor haciendo cosas con mis manos.', 'Me ayuda ver videos o dibujos animados sobre el tema.', 'Recuerdo lo que escucho en clase sin tomar apuntes.', 'Necesito moverme o manipular objetos para aprender.', 'Entiendo mapas o diagramas fácilmente.', 'Puedo repetir información después de escucharla una vez.', 'Prefiero realizar experimentos para aprender.', 'Me gusta usar colores y subrayar en mis apuntes.', 'Puedo seguir instrucciones habladas sin problema.', 'Aprendo construyendo, ensamblando o tocando cosas.', 'Me gustan los libros con muchas ilustraciones.', 'Prefiero explicaciones orales a leer textos.', 'Me resulta útil estudiar caminando o moviéndome.', 'Recuerdo imágenes más que palabras.', 'Aprendo canciones o poemas escuchándolos varias veces.', 'Necesito estar activo para entender lo que estudio.', 'Me atraen los cuadros, posters o materiales visuales.', 'Me gusta discutir temas en voz alta para aprenderlos.'];
$options = ['visual' => 'Visual', 'auditivo' => 'Auditivo', 'kinestesico' => 'Kinestésico'];
foreach ($questions as $index => $text) {
    echo '<p><strong>' . ($index + 1) . '. ' . $text . '</strong><br>';
    foreach ($options as $value => $label) {
        echo '<label><input type="radio" name="q' . $index . '" value="' . $value . '" required> ' . $label . '</label> ';
    }
    echo '</p>';
}
echo '<input type="submit" value="Enviar respuestas">';
echo '</form>';

$cm = get_coursemodule_from_id('solomontest', $id, 0, false, MUST_EXIST);
$context = context_module::instance($cm->id);
if (has_capability('mod/test:viewresults', $context)) {
    echo '<p><a href="results.php?id=' . $id . '">Ver resultados del grupo</a></p>';
}
echo $OUTPUT->footer();